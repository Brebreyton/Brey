/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lab1;

/**
 *
 * @author brait
 */

public class Cajero {
    public int billete50 = 0;
    public int billete20 = 0;
    public int billete10 = 0;
    public int billete5  = 0;
    public int billete2  = 0;
    public int billete1  = 0;
    
    
    
    public int getBalance() {
        return (billete50 * 50000)
             + (billete20 * 20000)
             + (billete10 * 10000)
             + (billete5  * 5000)
             + (billete2  * 2000)
             + (billete1  * 1000);
        
    }
    
    
    
    
    
}
