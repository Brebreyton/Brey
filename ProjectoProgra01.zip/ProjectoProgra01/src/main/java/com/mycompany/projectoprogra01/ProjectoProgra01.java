package com.mycompany.projectoprogra01;

import java.util.ArrayList;
import java.util.Scanner;

public class ProjectoProgra01 {
    
    static Scanner sc = new Scanner(System.in);
    
    static ArrayList<Estudiante> estudiantes = new ArrayList<>();
    static ArrayList<Cursos> cursos = new ArrayList<>();
    static ArrayList<Reserva> reservas = new ArrayList<>();

    public static void main(String[] args) {
        
       
        cargarCursos();
        int opcion;
        do{
            System.out.println("\n--- Seleccione su tramite ---");
            System.out.println("1. Registro de estudiante");
            System.out.println("2. Mostrar cursos");
            System.out.println("3. Reservar cursos");
            System.out.println("4. Mostrar cursos reservados");
            System.out.println("5. Salir");
            System.out.println("Ingrese el número de su tramite");
            
            opcion = sc.nextInt();
            sc.nextLine();
            
            switch (opcion){
                case 1:
                    registrarEstudiante();
                    break;
                case 2:
                    mostrarCursos();
                    break;
                case 3:
                    reservarCursos();
                    break;
                case 4:
                    mostrarReservas();
                    break;
                case 5:
                    System.out.println("Saliendo");
                    break;
                default:
                    System.out.println("Opción inválida");
            }
            
                    
        }while (opcion != 5);
        
    }
    
    static void cargarCursos(){
        cursos.add(new Cursos("BII-06","Calculo 1",227000,4));
        cursos.add(new Cursos("BIS-09","Contabilidad financiera",197000,3));
        cursos.add(new Cursos("BII-09","Probabilidad y estadistica",190000,3));
        cursos.add(new Cursos("BIs-06","Programación 1",207000,4));
    }
    
    static void registrarEstudiante(){
        System.out.print("Ingrese el nombre del estudiante: ");
        String nombre = sc.nextLine();
        System.out.print("Ingrese su ID: ");
        String id = sc.nextLine();
        estudiantes.add(new Estudiante(id, nombre));
        System.out.println("Estudiante registrado con éxito.");
    }
    
    static void mostrarCursos() {
        System.out.println("\n--- CURSOS DISPONIBLES ---");
        for (Cursos c : cursos) {
            System.out.println(c);
        }
        
    }
    
    static void reservarCursos(){
        System.out.print("\nIngrese ID del estudiante: ");
        String id = sc.nextLine();
        Estudiante est = buscarEstudiante(id);
        if (est == null) {
            System.out.println("Estudiante no encontrado. Regístrelo primero.");
            return;
        }
        mostrarCursos();
        System.out.print("Ingrese código del curso a reservar:");
        String codigo  = sc.nextLine();
        Cursos curso = buscarCurso(codigo);
        if (curso == null) {
            System.out.println("Curso no encontrado.");
            return;
        }
        
        if (curso.getCupos() >0){
            curso.reducirCupo();
            reservas.add(new Reserva(est, curso));
            System.out.println("Reserva realizada con éxito para " + est.getNombre() + " en " + curso.getCodigoCurso() + ".");
        }else{
            System.out.println("No hay cupos disponibles para este curso.");
        }
    
    }
    
    static void mostrarReservas(){
        System.out.println("\n--- RESERVAS ---");
        if (reservas.isEmpty()) {
            System.out.println("No hay reservas registradas.");
            return;
        }
        for (Reserva r : reservas){
            System.out.println(r);
        }
        
    }

    static Estudiante buscarEstudiante(String id) {
        for (Estudiante e : estudiantes) {
            if (e.getId().equals(id)) {
                return e;
            }
        }
        return null;
    }
    
    static Cursos buscarCurso(String codigo) {
        for (Cursos c : cursos) {
            if (c.getCodigoCurso().equalsIgnoreCase(codigo)) {
                return c;
            }
        }
        return null;
    }
}
