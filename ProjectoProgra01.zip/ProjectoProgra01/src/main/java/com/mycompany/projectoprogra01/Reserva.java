package com.mycompany.projectoprogra01;

public class Reserva {
    private Estudiante estudiante;
    private Cursos cursos;
    
    public Reserva(Estudiante estudiante, Cursos cursos){
        this.estudiante = estudiante;
        this.cursos = cursos;
    }
    
    public String toString(){
        return estudiante.getNombre() + " Reservó el curso " + cursos.getCodigoCurso() + " - " +cursos.toString();
    }
    
}
