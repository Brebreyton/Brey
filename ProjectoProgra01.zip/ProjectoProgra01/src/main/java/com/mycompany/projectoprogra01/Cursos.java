package com.mycompany.projectoprogra01;

public class Cursos {
    private String codigoCurso;
    private String nombreCurso;
    private double precio;
    private int cupos;
    
    public Cursos(String CodigoCurso, String nombreCurso, double precio, int cupos){
        this.codigoCurso = CodigoCurso;
        this.nombreCurso = nombreCurso;
        this.cupos = cupos;
        this.precio = precio;
                
    }
    
    public int getCupos(){
        return cupos;
    }
    
    public String getCodigoCurso(){
        return codigoCurso;
    }
    
    public void reducirCupo(){
        if(cupos > 0){
            cupos--;
        }
    }
    
    public String toString(){
        return nombreCurso + " - " + codigoCurso + " Precio Curso: " +precio+ " Cupos " +cupos;
    }
    
}
