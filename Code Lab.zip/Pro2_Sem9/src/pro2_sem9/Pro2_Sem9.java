/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pro2_sem9;

import AccesoDatos.SQLServerConn;

/**
 *
 * @author brait
 */
public class Pro2_Sem9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        SQLServerConn conn = new SQLServerConn();
        conn.establecerConn();
        
        // TODO code application logic here
    }
    
}
